Those "light" dat files are meant for n3ds builds, which can't load a full FBNeo build due to memory limitations.
