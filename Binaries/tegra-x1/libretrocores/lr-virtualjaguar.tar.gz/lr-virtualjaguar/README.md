# virtualjaguar-libretro

## _Port of Virtual Jaguar to Libretro_

---

<span align="center">
  <a href="https://github.com/libretro/virtualjaguar-libretro/actions/workflows/c-cpp.yml" alt="CI/CD">
    <img src="https://github.com/libretro/virtualjaguar-libretro/actions/workflows/c-cpp.yml/badge.svg" />
  </a>
  <a href="https://lgtm.com/projects/g/libretro/virtualjaguar-libretro/alerts/" alt="Total alerts">
    <img src="https://img.shields.io/lgtm/alerts/g/libretro/virtualjaguar-libretro.svg?logo=lgtm&logoWidth=18" />
  </a>
  <a href="https://lgtm.com/projects/g/libretro/virtualjaguar-libretro/context:cpp" alt="Language grade: C/C++">
    <img src="https://img.shields.io/lgtm/grade/cpp/g/libretro/virtualjaguar-libretro.svg?logo=lgtm&logoWidth=18" />
  </a>
</span>
                         
## Links
                                                                                                             
Upstream: `git clone http://shamusworld.gotdns.org/git/virtualjaguar`

Unofficial GitHub mirror: https://github.com/mirror/virtualjaguar

## Notices
                                                                                                             
Battery saves unsupported
