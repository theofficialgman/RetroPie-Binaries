SMSPlus-GX RS97
==================

It used to be based on SMS Plus 1.3 but then i realised SMS Plus GX had a lot of additions and was much better, while still being free software.
It is now based on SMS Plus GX, with some other changes too such as :
- Updated MAME FM & Z80 core based on upstream (YM core from CrabEmu, GPLv2 licensed. Z80's core is BSD licensed)
- PSG emulation based on CrabEmu's own PSG sound core. (also Maxim's psg as an option, set MAXIM_PSG)
- Multiple audio output supports (ALSA, OSS, Pulseaudio, Portaudio, libao)
- Numerous fixes so it can build & work properly on 64-bits. (as well as 32-bits of course)

And more...

This emulator is free software under the GPLv2 or later. See docs/license for more details.
Also, see docs/contributors to see who contributed (indirectly or directly) to SMS Plus (GX).
