libretro-o2em
==================

Port of O2EM to libretro.

Place "o2rom.bin" (required) in your RetroArch/libretro "System Directory" folder.

If you wish to use The Voice emulation, unzip the voice samples into a folder named "voice" under your RetroArch/libretro "System Directory" folder. There are two sets of voice samples: mainsamp.zip, which are the main voice samples, and sidsamp.zip which are the samples used by the game Sid the Spellbinder. You only need the latter if you want voice in that specific game.
