prosystem-libretro
==================

Port of ProSystem to libretro.
Bios are optionals.
Place them in your RetroArch/libretro "System Directory" folder.

NTSC/US bios name: "7800 BIOS (U).rom" 
PAL/EU bios name:  "7800 BIOS (E).rom" 
