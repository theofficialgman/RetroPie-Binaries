blueMSX-libretro
================

source http://sourceforge.net/p/bluemsx/code/HEAD/tree/trunk/blueMSX/Make/blueMSXlite/
svn://svn.code.sf.net/p/bluemsx/code/trunk

this core requires the two folders named Machines/ and Databases/ from standalone blueMSX
copied inside your frontend's system directory.

you can get these from the official windows standalone version of bluemsx (http://www.bluemsx.com/)
or any other binary package.
